<?php
require_once __DIR__ . '/../function.php';

class train extends DB
{
    protected $table = 'traindetails';

    public function addtrain($train_no, $from1, $to1, $price, $departure_time, $arrival_time, $time, $class_type, $date)
    {

        return $this->save(compact('train_no', 'from1', 'to1', 'price', 'departure_time', 'arrival_time', 'time', 'class_type', 'date'));
    }
    public function fetchdata()
    {
        $result = mysqli_query($this->dbh, "select * from traindetails");
        return $result;

    }

    public function fetchonerecord($userid)
    {
        return $this->select('*')->where('trainid', '=', $userid)->get();
    }

    public function updatetrain($tno, $from, $to, $price, $dtime, $atime, $time, $date, $userid)
    {
        return $this->where('trainid', '=', $userid)->update([
            'train_no' => $tno,
            'from1' => $from,
            'to1' => $to,
            'price' => $price,
            'departure_time' => $dtime,
            'arrival_time' => $atime,
            'time' => $time,
            'date' => $date,
        ]);
    }

    public function deletetrain($rid)
    {
        return $this->where('trainid', '=', $rid)->delete();
    }

}

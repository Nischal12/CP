<?php
require_once __DIR__ . '/../function.php';

class book extends DB
{
    protected $table = 'book';

    public function createbooking($train_no, $class_type, $from1, $to1, $date, $departure_time, $arrival_time)
    {

        return $this->save(compact('train_no', 'class_type', 'from1', 'to1', 'date', 'departure_time', 'arrival_time'));
    }

    public function fetchdata()
    {
        $result = mysqli_query($this->dbh, "select * from book");
        return $result;

    }
    public function deletebook($rid)
    {
        return $this->where('id', '=', $rid)->delete();
    }

}

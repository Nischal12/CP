<?php
include '../function.php';

class feedback extends DB
{
    protected $table = 'feedback';
    public function addfeedback($name, $email, $date, $comment)
    {

        return $this->save(compact('name', 'email', 'date', 'comment'));
    }

}

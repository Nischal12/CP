<?php
include '../function.php';

class passenger extends DB
{
    protected $table = 'passengerdetails';
    public function addpassenger($name, $address, $contact, $email, $no_of_passenger)
    {

        return $this->save(compact('name', 'address', 'contact', 'email', 'no_of_passenger'));
    }

}

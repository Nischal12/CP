<?php
include '../function.php';

class registeruser extends DB
{
    protected $table = 'user';
    public function usernameavailblty($uname)
    {
        $result = mysqli_query($this->dbh, "select username FROM user WHERE username='$uname'");
        return $result;

    }

    // Function for registration
    public function register($name, $email, $password)
    {
        return $this->save(compact('name', 'email', 'password'));
    }

}

<?php
include '../function.php';

class loginuser extends DB
{
    protected $table = 'user';

    public function login($email, $pasword)
    {
        return $this->select('userid', 'name')
            ->where('email', '=', $email)
            ->where('password', '=', $pasword)
            ->get();
    }

}

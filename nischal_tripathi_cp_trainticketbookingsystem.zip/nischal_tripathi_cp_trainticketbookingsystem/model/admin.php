<?php
include '../function.php';

class admin extends DB
{
    protected $table = 'tblusers';

    public function signin($uname, $password)
    {
        return $this->select('id', 'FullName')
            ->where('username', '=', $uname)
            ->where('password', '=', $password)
            ->get();
    }

}

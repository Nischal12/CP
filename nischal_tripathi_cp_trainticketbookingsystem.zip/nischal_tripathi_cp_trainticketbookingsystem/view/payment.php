<?php

require_once '../model/payment.php';
$userdata = new payment();

if (isset($_POST['insert'])) {

    $name = $_POST['name'];
    $pcode = $_POST['pcode'];
    $cardtype = $_POST['cardtype'];
    $cardno = $_POST['cardno'];
    $edate = $_POST['edate'];

    $sql = $userdata->addpayment($name, $pcode, $cardtype, $cardno, $edate);
    if ($sql) {

        echo "<script>alert('Payment made sucessfully.');</script>";
        echo "<script>window.location.href='../index.php'</script>";
    } else {

        echo "<script>alert('Something went wrong. Please try again');</script>";
        echo "<script>window.location.href='payment.php'</script>";
    }
}
?>




<!DOCTYPE html>
<html>

<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Payment method</title>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/payment.css">

</head>

<body>
    <div class="container-fluid">
        <header>

        </header>
        <div class="creditCardForm">
            <div class="heading">
                <h1>Make Payment</h1>
            </div>
            <div class="payment">
            <form action='' method="post" role="form"class="form">
                    <div class="form-group owner">
                        <label for="owner">Owner</label>
                        <input type="text" name="name" class="form-control" required placeholder=" " id="owner">
                    </div>
                    <div class="form-group Card number">
                        <label for="cvv">Postal Code</label>
                        <input type="text" class="form-control" name="pcode" required placeholder=" " id="pcode">
                    </div>
                    <div class="form-group" id="card-number-field">
                        <label for="cardNumber">Card Number</label>
                        <input type="text" class="form-control" name="cardno" required placeholder=" " id="cardNumber">
                    </div>
                    <div class="form-group"  id="cardtype">
                        <label>Card Type</label>
                        <select name="cardtype">
                            <option >Visa Card</option>
                            <option >Master Card </option>
                            <option>March</option>
                        </select>

                    </div>
                    <div class="form-group Card number ">
                        <label for="cvv">Expiry Date</label>
                        <input type="date" class="form-control" required placeholder=" " name="edate">
                    </div>

                    <div class="form-group" id="credit_cards">
                        <img src="../image/visa.jpg" id="visa">
                        <img src="../image/mastercard.jpg" id="mastercard">
                        <img src="../image/amex.jpg" id="amex">
                    </div>
                    <div class="form-group" id="pay-now">
                        <input type="submit" class="btn btn-default" name="insert" value="Confirm">
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="assets/js/jquery.payform.min.js" charset="utf-8"></script>
    <script src="assets/js/script.js"></script>
</body>

</html>

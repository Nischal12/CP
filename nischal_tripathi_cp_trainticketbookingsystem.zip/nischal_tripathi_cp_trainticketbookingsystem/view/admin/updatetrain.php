<?php
session_start();
error_reporting(0);
require_once '../../model/trainrecord.php';
$updatedata = new train();

if (isset($_POST['update'])) {

    $userid = intval($_GET['id']);
    $tno = $_POST['train_no'];
    $from = $_POST['from'];
    $to = $_POST['to'];
    $price = $_POST['price'];
    $dtime = $_POST['dtime'];
    $atime = $_POST['atime'];
    $time = $_POST['time'];
    $class = $_POST['class_type'];
    $date = $_POST['date'];

    //Function Calling
    $sql = $updatedata->updatetrain($tno, $from, $to, $price, $dtime, $atime, $time, $class, $date, $userid);

    // Mesage after updation
    echo "<script>alert('Record Updated successfully');</script>";
    // Code for redirection
    echo "<script>window.location.href='viewtrain.php'</script>";
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Dashboard">
    <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">

    <title>Admin | Change Password</title>
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/style-responsive.css" rel="stylesheet">
  </head>

  <body>

  <section id="container" >
      <header class="header black-bg">
              <div class="sidebar-toggle-box">
                  <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
              </div>
            <a href="#" class="logo"><b>Admin Dashboard</b></a>
            <div class="nav notify-row" id="top_menu">



                </ul>
            </div>
            <div class="top-menu">
            	<ul class="nav pull-right top-menu">
                    <li><a class="logout" href="logout.php">Logout</a></li>
            	</ul>
            </div>
        </header>
      <aside>
          <div id="sidebar"  class="nav-collapse ">
              <ul class="sidebar-menu" id="nav-accordion">

              	  <p class="centered"><a href="#"><img src="assets/img/ui-sam.jpg" class="img-circle" width="60"></a></p>
              	  <h5 class="centered"><a class="logout" href="javascript:;"><?=$_SESSION['fname']?></a></h5>
                    <li class="sub-menu">
                      <a href="train.php" >
                          <i class="fa fa-users"></i>
                          <span>Add train details</span>
                      </a>

                  </li>
                  <li class="sub-menu">
                      <a href="viewtrain.php">
                          <i class="fa fa-file"></i>
                          <span>Train details</span>
                      </a>
                  </li>

                  <li class="sub-menu">
                      <a href="booked.php" >
                          <i class="fa fa-users"></i>
                          <span>Booking details</span>
                      </a>

                  </li>



              </ul>
          </div>
      </aside>
      <section id="main-content">
          <section class="wrapper">
          	<h3><i class="fa fa-angle-right"></i> Train Details </h3>
				<div class="row">
                <div class="col-md-6">
          <fieldset>
          <div class="content-panel">
				   <div class="text-center">
                    <h2>Update Train Details</h2>
				   </div>
                   <?php
// Get the userid
$userid = intval($_GET['id']);
$onerecord = new train();
$data = $onerecord->fetchonerecord($userid);

$cnt = 1;
if ($row = reset($data)) {
    ?>

                  <form action="" method="post" role="form"class="form">

                       <div class="form-group owner">
                            <input type="text" class="form-control" name="train_no" value="<?php echo htmlentities($row['train_no']); ?>" required placeholder="Train NO.">
                            <div class="validation"></div>
               </div>

                           <div class="form-group owner">
                            <input type="text" class="form-control" name="from" value="<?php echo htmlentities($row['from1']); ?>" required placeholder="From"
                             data-msg="Please enter a valid name" />
                            <div class="validation"></div>
                           </div>
                           <div class="form-group owner">
                            <input type="text" class="form-control" name="to" value="<?php echo htmlentities($row['to1']); ?>" required placeholder="To"
                             data-msg="Please enter a valid Destination name" />
                            <div class="validation"></div>
                           </div>
                           <div class="form-group owner">
                            <input type="text" class="form-control" name="dtime" value="<?php echo htmlentities($row['departure_time']); ?>" required placeholder="Departure Time"
                             data-msg="Please enter a valid time" />
                            <div class="validation"></div>
                           </div>
                           <div class="form-group owner">
                            <input type="text" class="form-control" name="atime" value="<?php echo htmlentities($row['arrival_time']); ?>" required placeholder="Arrival Time"
                             data-msg="Please enter a valid Arrival time" />
                            <div class="validation"></div>
                           </div>
                           <div class="form-group owner">
                            <input type="text" class="form-control" name="time" value="<?php echo htmlentities($row['time']); ?>" required placeholder="Time"
                             data-msg="Please enter a valid time duration" />
                            <div class="validation"></div>
                           </div>
                           <div class="form-group">
                               <label>Class Type</label><br>
                               <select name="class_type"  class="form-control" value="<?php echo htmlentities($row['class_type']); ?>">
                               <option> Business</option>
                               <option>Economic </option>

                           </select>
                           </div>
                           <div class="form-group">
                            <input type="text" class="form-control" name="price" value="<?php echo htmlentities($row['price']); ?>" required placeholder="Price"  >
                            <div class="validation"></div>
                           </div>
                           <div class="form-group">
                            <input type="date" class="form-control" name="date" value="<?php echo htmlentities($row['date']); ?>" required placeholder="Expiry Date"  >
                            <div class="validation"></div>
                           </div>

                           <?php }?>

                           <div class="text-center"><input type="submit" name="update" value="Update" class="btn gradient-bg mt-5"></div>

                       </form>
                      </div>
                  </div>
              </div>
		</section>
      </section></section>
    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
    <script src="assets/js/jquery.scrollTo.min.js"></script>
    <script src="assets/js/jquery.nicescroll.js" type="text/javascript"></script>
    <script src="assets/js/common-scripts.js"></script>
  <script>
      $(function(){
          $('select.styled').customSelect();
      });

  </script>

  </body>
</html>


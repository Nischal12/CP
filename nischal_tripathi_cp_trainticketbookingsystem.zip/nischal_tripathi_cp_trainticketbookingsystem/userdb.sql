-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 20, 2019 at 07:46 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `userdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE `book` (
  `id` int(11) NOT NULL,
  `train_no` varchar(30) NOT NULL,
  `from1` varchar(50) NOT NULL,
  `to1` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `class_type` varchar(30) NOT NULL,
  `date` date NOT NULL,
  `departure_time` varchar(50) NOT NULL,
  `arrival_time` varchar(50) NOT NULL,
  `paid` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`id`, `train_no`, `from1`, `to1`, `username`, `class_type`, `date`, `departure_time`, `arrival_time`, `paid`) VALUES
(19, 'YE-12', 'ktm', 'brt', '', 'Business', '2019-09-19', '6:00am', '7:00am', '0'),
(21, 'YE-12', 'ktm', 'brt', '', 'Business', '2019-09-19', '6:00am', '7:00am', '0'),
(22, 'YE-12', 'ktm', 'brt', '', 'Business', '2019-09-19', '6:00am', '7:00am', '0'),
(23, 'YE-12', 'ktm', 'brt', '', 'Business', '2019-09-19', '6:00am', '7:00am', '0'),
(24, 'YE-12', 'pkr', 'ktm', '', 'Business', '2019-09-09', '6:00am', '7:00am', ''),
(25, 'YE-12', 'pkr', 'ktm', '', 'Business', '2019-09-09', '6:00am', '7:00am', ''),
(26, 'YE-123', 'india', 'kathmandu', '', 'Economic', '2019-09-22', '9:00am', '10:am', '');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `fid` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `date` date NOT NULL,
  `comment` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`fid`, `name`, `email`, `date`, `comment`) VALUES
(1, 'Nischal', 'nischal@gmail.com', '2019-09-11', 'Hello dkkej hjfubu'),
(2, '', '', '0000-00-00', ''),
(3, '', '', '0000-00-00', '');

-- --------------------------------------------------------

--
-- Table structure for table `passengerdetails`
--

CREATE TABLE `passengerdetails` (
  `passenger_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `contact` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `no_of_passenger` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `passengerdetails`
--

INSERT INTO `passengerdetails` (`passenger_id`, `name`, `address`, `contact`, `email`, `no_of_passenger`) VALUES
(1, '', '', '', '0', 0),
(3, 'Nischal', 'ktm', '134567', 'nischal@gmail.com', 2),
(4, 'ram', 'ktm', '134567', 'ram@gmail.com', 2),
(5, 'ram', 'ktm', '134567', 'ram@gmail.com', 2),
(6, 'nischal', 'chabahil', '9810157495', 'nischal.tripathi1@gmail.com', 3),
(7, 'nischal', 'chabahil', '9810157495', 'nischal.tripathi1@gmail.com', 3),
(8, 'nischal', 'chabahil', '9810157495', 'nischal.tripathi1@gmail.com', 3),
(9, 'nischal', 'chabahil', '9810157495', 'nischal.tripathi1@gmail.com', 100),
(10, 'nischal', 'chabahil', '9810157495', 'nischal.tripathi1@gmail.com', 100),
(11, 'nischal', 'chabahil', '9810157495', 'timdipti6@gmail.com', 100);

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `payment_id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `postal_code` varchar(20) NOT NULL,
  `card_type` varchar(30) NOT NULL,
  `card_no` varchar(100) NOT NULL,
  `expiry_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`payment_id`, `name`, `postal_code`, `card_type`, `card_no`, `expiry_date`) VALUES
(2, 'Nischal', '1234', '123444', '1234567', '2019-09-18'),
(3, 'Nischal', '1234', 'visa Card', '12345y', '2019-09-03'),
(4, 'Nischal', '1234', '123444', '234dfgh', '2019-09-11'),
(5, 'Nischal', '1234', '02', '1234', '0000-00-00'),
(7, 'Nischal', '1234', '01', '12345678', '2019-09-02'),
(8, 'nischal', '00977', 'Visa Card', '23456789876', '2019-09-12'),
(9, 'nischal', '00977', 'Visa Card', '123456789876543', '2019-09-17'),
(10, 'Chaudhary group', '00977', 'Visa Card', '123456789', '2019-09-11'),
(11, 'nischal', '00977', 'Master Card', '1234567890876543', '2019-09-29'),
(12, 'nischal', '00977', 'Visa Card', '123456765434567', '2019-09-26'),
(13, 'Chaudhary group', '00977', 'Visa Card', '123456765434567', '2019-09-06');

-- --------------------------------------------------------

--
-- Table structure for table `tblusers`
--

CREATE TABLE `tblusers` (
  `id` int(11) NOT NULL,
  `FullName` varchar(120) DEFAULT NULL,
  `Username` varchar(120) DEFAULT NULL,
  `UserEmail` varchar(200) DEFAULT NULL,
  `Password` varchar(250) DEFAULT NULL,
  `RegDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblusers`
--

INSERT INTO `tblusers` (`id`, `FullName`, `Username`, `UserEmail`, `Password`, `RegDate`) VALUES
(2, 'nischal tripathi', 'Nischal', 'nischal.tripathi1@gmail.com', 'd41d8cd98f00b204e9800998ecf8427e', '2019-09-20 17:35:00'),
(4, 'nischal', 'nischal', 'nischal@gmail.com', '202cb962ac59075b964b07152d234b70', '2019-09-15 18:15:00');

-- --------------------------------------------------------

--
-- Table structure for table `traindetails`
--

CREATE TABLE `traindetails` (
  `trainid` int(11) NOT NULL,
  `train_no` varchar(30) NOT NULL,
  `from1` varchar(30) NOT NULL,
  `to1` varchar(30) NOT NULL,
  `price` varchar(50) NOT NULL,
  `departure_time` varchar(30) NOT NULL,
  `arrival_time` varchar(30) NOT NULL,
  `time` varchar(50) NOT NULL,
  `class_type` varchar(50) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `traindetails`
--

INSERT INTO `traindetails` (`trainid`, `train_no`, `from1`, `to1`, `price`, `departure_time`, `arrival_time`, `time`, `class_type`, `date`) VALUES
(6, 'YE-12', 'pkr', 'ktm', 'Rs.3500', '6:00am', '7:00am', '1hr', 'Business', '2019-09-09'),
(8, 'YE-23', 'pkr', 'brt', 'Rs.4000', '6:00am', '7:00am', '1hr', 'Business', '2019-09-12'),
(9, 'YE-123', 'india', 'kathmandu', '5000', '9:00am', '10:am', '10:00', 'Economic', '2019-09-22');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `userid` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`userid`, `name`, `email`, `password`) VALUES
(1, 'nischal', 'nischal@gmail.com', '123'),
(2, 'Nischal', 'nischal@gmail.com', '202cb962ac59075b964b07152d234b70');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `book`
--
ALTER TABLE `book`
  ADD PRIMARY KEY (`id`),
  ADD KEY `train_no` (`train_no`),
  ADD KEY `username` (`username`),
  ADD KEY `id` (`id`),
  ADD KEY `id_2` (`id`),
  ADD KEY `class_type` (`class_type`),
  ADD KEY `date` (`date`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`fid`);

--
-- Indexes for table `passengerdetails`
--
ALTER TABLE `passengerdetails`
  ADD PRIMARY KEY (`passenger_id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `tblusers`
--
ALTER TABLE `tblusers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `traindetails`
--
ALTER TABLE `traindetails`
  ADD PRIMARY KEY (`trainid`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `book`
--
ALTER TABLE `book`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `fid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `passengerdetails`
--
ALTER TABLE `passengerdetails`
  MODIFY `passenger_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tblusers`
--
ALTER TABLE `tblusers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `traindetails`
--
ALTER TABLE `traindetails`
  MODIFY `trainid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
